

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.CMLEpanS.js","_app/immutable/chunks/disclose-version.BlAstWID.js","_app/immutable/chunks/runtime.CuGXy-Xm.js"];
export const stylesheets = ["_app/immutable/assets/0.6oe5jHiL.css"];
export const fonts = ["_app/immutable/assets/Poppins-Regular.CTKNfV9P.ttf","_app/immutable/assets/Poppins-Medium.Cxde2ZoM.ttf","_app/immutable/assets/Poppins-SemiBold.B_fPDAUb.ttf","_app/immutable/assets/Poppins-Bold.qTAUjFF7.ttf","_app/immutable/assets/Poppins-ExtraBold.W_qeO1XX.ttf"];
